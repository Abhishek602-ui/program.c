#include<stdio.h>
int main()
{
     int x[10][10],row,col,i,j,sum=0;
     printf("enter row and col.");
     scanf("%d%d",&i,&j);
     
     for(row=0;row<i;row++)
     {
          for(col=0;col<j;col++)
          {
               scanf("%d",&x[row][col]);
          }
     }
   
    for(row=0;row<i;row++)
    {
        sum=sum+x[row][i-row-1];
    }
      printf("%d\t",sum);
          
   
     return 0;
     
}